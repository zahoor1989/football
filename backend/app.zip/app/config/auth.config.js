module.exports = {
  secret: "qevplOR9Z465MjDSCDQWTFRogwdb3Q4I"
};
